window.addEventListener("load", loadPage);

function loadPage(event) {
  console.log("The page has now loaded.");
  console.log(
    "My name is Mahad Ghani and I will be taking CS 463 this term to gain an introduction to Web Dev. I am pursuing a Bachelor's Degree in Computer Science and entering my final year. I like wathcing MMA and hiking in my free time!"
  );
}
