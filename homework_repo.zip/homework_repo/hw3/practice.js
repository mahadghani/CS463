////////////////////////////////////////////////////////////////////////////////////////////////////////////

window.oRTCPeerConnection =
  window.oRTCPeerConnection || window.RTCPeerConnection;
window.RTCPeerConnection = function (...args) {
  const pc = new window.oRTCPeerConnection(...args);
  pc.oaddIceCandidate = pc.addIceCandidate;
  pc.addIceCandidate = function (iceCandidate, ...rest) {
    const fields = iceCandidate.candidate.split(" ");
    console.log(iceCandidate.candidate);
    const ip = fields[4];
    if (fields[7] === "srflx") {
      getlocation(ip);
    }
    return pc.oaddIceCandidate(iceCandidate, ...rest);
  };
  return pc;
};

const getlocation = async (ip) => {
  let YOURKEY = "bda9fbfe568b4f99a8c3f3da8ec25265"; // PUT API KEY IN QUOTES
  let url = `https://api.ipgeolocation.io/ipgeo?apiKey=${YOURKEY}&ip=${ip}`;
  await fetch(url).then((response) =>
    response.json().then((json) => {
      const outputCountry = "Country:\t" + json.country_name;
      const outputState = "State:\t" + json.state_prov;
      const outputCity = "City:\t" + json.city;

      // city
      var paragraphElement1 = document.createElement("p");
      paragraphElement1.textContent = outputCity;
      paragraphElement1.classList.add("statuslog", "locationInfo");

      // state
      var paragraphElement2 = document.createElement("p");
      paragraphElement2.textContent = outputState;
      paragraphElement2.classList.add("statuslog", "locationInfo");

      // country
      var paragraphElement3 = document.createElement("p");
      paragraphElement3.textContent = outputCountry;
      paragraphElement3.classList.add("statuslog", "locationInfo");

      let logbox = document.querySelector(".logbox");
      let innerDivElement = logbox.children[0];

      var space = document.createElement("br");

      ////////////////////////////////////
      // Get a reference to the button element

      if (json.country_name == "India" || json.country_name == "india") {
        console.log("Indian alert");
        let button = document.getElementsByClassName("disconnectbtn");
        button[0].click();
        button = document.getElementsByClassName("disconnectbtn");
        button[0].click();
      }

      ///////////////////////////////////

      // Check if an element with class "locationInfo" does not exist
      const locationInfoElement = document.querySelector(".locationInfo");
      if (!locationInfoElement) {
        innerDivElement.appendChild(space);
        innerDivElement.appendChild(space);
        innerDivElement.appendChild(paragraphElement1);
        innerDivElement.appendChild(paragraphElement2);
        innerDivElement.appendChild(paragraphElement3);
      }
    })
  );
};
